import "./Footer.css";

const Footer = () => {
    return (
        <div className="Footer">
            @ copyright 2024
        </div>
    );
};

export default Footer;