const firebaseConfig = {
  apiKey: "AIzaSyAVcaQlCCatMe-nDBMdS2cOrOO3RFKjPTY",
  authDomain: "portfolio-fid.firebaseapp.com",
  projectId: "portfolio-fid",
  storageBucket: "portfolio-fid.appspot.com",
  messagingSenderId: "891805970435",
  appId: "1:891805970435:web:dd05ef125dc166608b5e36",
  measurementId: "G-452JMY48JB"
};

export default firebaseConfig;
